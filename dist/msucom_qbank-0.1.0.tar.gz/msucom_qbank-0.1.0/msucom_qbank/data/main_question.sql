INSERT INTO question (quiz_ID, question, answer, course) VALUES ('1', 'What is the relationship between funk and soul?', 'Balls', 'BRO531');
INSERT INTO question (quiz_ID, question, answer, course) VALUES ('1', 'Who is the man?', 'You', 'BRO531');
INSERT INTO question (quiz_ID, question, answer, course) VALUES ('1', 'What time is it?', 'Groove-thirty', 'BRO531');